package de.prestigio.solutions.ShiftScheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchichtplanerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchichtplanerApplication.class, args);
	}

}
